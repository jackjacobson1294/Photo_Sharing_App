------

Example Project Below README.md:

------

### Group Name: groupXX

### Members:
  - Prateek Sachdeva (prateeks): setup the database, setup the routes, did the project alone

### Live Access:
  - [URL For Running Version](http://google.com)

### Extra:
  - We called our `/pic` endpoint `/foto` (which you shouldn't but note any other special instructions here)
# p1_xjw77p
