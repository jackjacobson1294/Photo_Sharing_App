from flask import *
import extensions

pic = Blueprint('pic', __name__, template_folder='templates')

@pic.route('/pic')
def pic_route():
	db = extensions.connect_to_database()
	cur = db.cursor()
	pic_id = request.args.get('picid')
	cur.execute('USE group120db')
	cur.execute('SELECT * FROM Photo WHERE picid = "%s"' % (pic_id))
	pic = cur.fetchall()
	cur.execute('SELECT * FROM Contain WHERE picid = "%s"' % (pic_id))
	pic_in_contain = cur.fetchall()
	album_id = -1
	if len(pic_in_contain) != 0:
		album_id = pic_in_contain[0]['albumid']
	cur.execute('SELECT * FROM Contain WHERE albumid = %d' %  (album_id))
	album = cur.fetchall()
	prevID = ''
	nextID = ''
	for i in range(0, len(album)):
		if(album[i]['picid'] == pic_id):
			if(len(album) != 1):
				if(i != 0 and i != len(album) - 1):
					prevID = album[i - 1]['picid']
					nextID = album[i + 1]['picid']
				elif(i == 0):
					nextID = album[i + 1]['picid']
				else:
					prevID = album[i - 1]['picid']
	options = {
        "album": album,
        "album_id": album_id,
        "pic" : pic,
        "prevID": prevID,
        "nextID": nextID
    }

	return render_template("pic.html", **options)