from flask import *
import extensions

main = Blueprint('main', __name__, template_folder='templates')

@main.route('/')
def main_route():
    db = extensions.connect_to_database()
    cur = db.cursor()
    cur.execute('use group120db')
    cur.execute('SELECT username FROM User')
    users = cur.fetchall()
    return render_template("index.html", users=users)

