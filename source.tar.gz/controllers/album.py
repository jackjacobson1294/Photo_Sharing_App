from flask import *
import extensions
import os, sys
import hashlib
from werkzeug.utils import secure_filename

UPLOAD_FOLDER = '/vagrant/p1/static/images'
ALLOWED_EXTENSIONS = set(['txt', 'pdf', 'png', 'jpg', 'jpeg', 'gif'])
app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
album = Blueprint('album', __name__, template_folder='templates')

def allowed_file(filename):
    return '.' in filename and \
        filename.rsplit('.', 1)[1] in ALLOWED_EXTENSIONS
album = Blueprint('album', __name__, template_folder='templates')

@album.route('/album/edit', methods=['GET'])
def album_edit_route():
    db = extensions.connect_to_database()
    cur = db.cursor()
    album_id = int(request.args.get('albumid'))
    cur.execute('USE group120db')
    cur.execute('SELECT * FROM Contain WHERE albumid = %d' % (album_id))
    pics = cur.fetchall()
    cur.execute('SELECT * FROM Photo')
    photos = cur.fetchall()
    options = {
        "edit": True,
        "album_id": album_id,
        "photos": photos,
        "pics": pics
    }
    return render_template("album.html", **options)

@album.route('/album')
def album_route():
    db = extensions.connect_to_database()
    cur = db.cursor()
    album_id = int(request.args.get('albumid'))
    if album_id < 1:
        abort(404)
    cur.execute('USE group120db')
    cur.execute('SELECT * FROM Contain WHERE albumid = %d' % (album_id))
    pics = cur.fetchall()
    cur.execute('SELECT * FROM Photo')
    photos = cur.fetchall()
    options = {
        "edit": False,
        "album_id": album_id,
        "pics": pics,
        "photos": photos
    }
    return render_template("album.html", **options)




@album.route('/album/edit', methods=['POST'])
def album_op_route():
    db = extensions.connect_to_database()
    cur = db.cursor()
    album_id = int(request.form.get('albumid'))
    if album_id < 1:
        abort(404)
    picid = request.form.get('picid')
    op = request.form.get('op')
    cur.execute('USE group120db')
    if op == "delete":
        cur.execute('SELECT * FROM Contain WHERE picid = "%s"' % (picid))
        picids = cur.fetchall()
        cur.execute('DELETE FROM Contain WHERE picid = "%s"' % (picid))
        for pic in picids:
            cur.execute('SELECT format FROM Photo WHERE picid = "%s"' % pic['picid'])
            format = cur.fetchall()[0]['format'];
            cur.execute('DELETE FROM Photo WHERE picid = "%s"' % (picid))
            os.remove('/vagrant/p1/static/images/' + picid + "." + str(format))
        cur.execute('UPDATE Album SET lastupdated = CURRENT_TIME() WHERE albumid = "%s"' % (album_id))
    else:
        file_name = request.files['filename']
        temp_file_name = file_name.filename
        album_id = int(request.form.get('albumid'))
        #reload page if the file format is bad 
        pic_format = temp_file_name[-3:]
        m = hashlib.md5(str(album_id) + temp_file_name)
        pic_id = m.hexdigest()
        final_file_name = str(pic_id) + "." + pic_format
        file_name.save(os.path.join(app.config['UPLOAD_FOLDER'], final_file_name))
        db = extensions.connect_to_database()
        cur = db.cursor()
        cur.execute('USE group120db')
        cur.execute('SELECT picid FROM Photo WHERE picid = "%s"' % (pic_id))
        existing_pic = cur.fetchall()
        if not existing_pic:
            cur.execute('INSERT INTO Photo (picid, format, picDate) VALUES("%s", "%s", CURRENT_TIME())' % (pic_id, pic_format))
            cur.execute('SELECT * FROM Contain')
            max_seq = cur.fetchall()
            max_num = 0;
            for pics in max_seq:
                if int(pics['sequencenum']) > max_num:
                    max_num = int(pics['sequencenum'])
            max_num = max_num + 1
            cur.execute('INSERT INTO Contain (sequencenum, albumid, picid, caption) VALUES(%d, %d, "%s", "%s")' % (max_num, album_id, pic_id, ""))
            cur.execute('UPDATE Album SET lastupdated = CURRENT_TIME() WHERE albumid = "%s"' % (album_id))

    return redirect(url_for('album.album_edit_route', albumid=album_id))
