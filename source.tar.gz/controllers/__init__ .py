from album import *
from albums import *
from pic import *
from main import *